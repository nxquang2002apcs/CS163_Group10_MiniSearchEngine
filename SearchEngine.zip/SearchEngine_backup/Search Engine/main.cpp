#include "Function.h"
#include "ConsoleManagement.h"

int main() {	
	searchEngine engine;
	
	File file;
	ifstream in;
	TrieNode* root[100];
	TrieNode* stopWord = engine.createNode();
	string path = "../Data/";
	engine.Initialize(root, stopWord, path);

	int choice = 1;
	string query;
	int choice2;
	while (choice != 3) {
		engine.titleInterface(choice);
		system("cls");
		if (choice == 1)
		{
			engine.readInQuery(query);
			engine.searchInterface(choice2);

			while (choice2 != 1 && choice2 != 2 && choice2 != 3)
			{
				system("cls");
				gotoXY(15, 2);
				cout << char(218);
				for (int i = 0; i < 86; ++i)
					cout << char(196);
				cout << char(191);

				gotoXY(15, 3); cout << char(179);
				gotoXY(102, 3); cout << char(179);

				gotoXY(15, 4);
				cout << char(192);
				for (int i = 0; i < 86; ++i)
					cout << char(196);
				cout << char(217);

				gotoXY(17, 3);
				cout << "QUERY: " << query;

				engine.searchInterface(choice2);
			}
			if (choice2 == 1) {
				system("cls");
				gotoXY(15, 2);
				cout << char(218);
				for (int i = 0; i < 86; ++i)
					cout << char(196);
				cout << char(191);

				gotoXY(15, 3); cout << char(179);
				gotoXY(102, 3); cout << char(179);

				gotoXY(15, 4);
				cout << char(192);
				for (int i = 0; i < 86; ++i)
					cout << char(196);
				cout << char(217);

				gotoXY(17, 3);
				cout << "QUERY: " << query;
				cout << endl << endl;
				engine.searchProcess(query, root, stopWord);
				system("pause");
			} 
			else if (choice2 == 2) {
				system("cls");
				gotoXY(15, 2);
				cout << char(218);
				for (int i = 0; i < 86; ++i)
					cout << char(196);
				cout << char(191);

				gotoXY(15, 3); cout << char(179);
				gotoXY(102, 3); cout << char(179);

				gotoXY(15, 4);
				cout << char(192);
				for (int i = 0; i < 86; ++i)
					cout << char(196);
				cout << char(217);

				gotoXY(17, 3);
				cout << "QUERY: " << query;

				engine.historySuggestionInterface(query);
				system("cls");
				gotoXY(15, 2);
				cout << char(218);
				for (int i = 0; i < 86; ++i)
					cout << char(196);
				cout << char(191);

				gotoXY(15, 3); cout << char(179);
				gotoXY(102, 3); cout << char(179);

				gotoXY(15, 4);
				cout << char(192);
				for (int i = 0; i < 86; ++i)
					cout << char(196);
				cout << char(217);

				gotoXY(17, 3);
				cout << "QUERY: " << query << endl << endl;

				engine.searchProcess(query, root, stopWord);
				system("pause");
			}
			if (choice2 == 3) continue;
		}
		if (choice == 2) {
			string path = "history.txt";
			engine.viewHistory(path);
		}
	}

	for (int i = 0; i < 100; ++i)
		engine.releaseTrie(root[i]);

	

	return 0;
}

/*
	TrieNode* root = engine.createNode();
	TrieNode* stopword = engine.createNode();
	string path = "../Data/";
	ifstream in;
	engine.inputFile(root, in, path + "001.txt");
	engine.readFileStopWord(stopword, in, "stopwords.txt");
	File file;
	file.name = "001.txt";
	file.score = 0;
	string query;
	cout << "QUERY: ";
	getline(cin, query);
	cout << "Result: ";
	if (engine.searchTrie(root, nullptr, file.pos, file.score, query))
		cout << "True" << endl;
	else cout << "False" << endl;

	cout << "Score: " << file.score << endl;
	cout << "Position: ";
	for (int i = 0; i < file.pos.size(); ++i)
		cout << file.pos[i] << " ";
	cout << endl;

	cout << "===============================================================================" << endl;
	cout << "001.txt" << endl;
	engine.display(file, path);

	engine.releaseTrie(root);
*/