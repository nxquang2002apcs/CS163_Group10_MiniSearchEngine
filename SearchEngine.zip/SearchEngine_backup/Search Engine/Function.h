#ifndef _SEARCH_ENGINE_H_
#define _SEARCH_ENGINE_H_

#include <iostream>
#include <string>
#include<sstream>
#include<vector>
#include<fstream>
#include<algorithm>
#include<set>

using namespace std;

struct TrieNode {
	TrieNode* children[43];  //0-9: number; 10-35: alphabet; 36: space; 37: dot(.); 38:(#); 39:(%); 40:($); 41:(-); 
							 //42 for special word: � , & ,... no accepted character but stand alone as a word   
	bool isTitle;		
	bool isEndOfWord;		
	vector<int> pos;
};
struct File {
	string name;
	vector<int> pos;
	int score;
};

class searchEngine {
public:
	void Initialize(TrieNode* root[100], TrieNode* stopWord, string path);	//Quang
	TrieNode* createNode();				//Quang
	bool isNumber(char key);			//Quan
	bool isAlphabet(char key);			//Quan
	string intToString(int num);		//Quan
	string floatToString(float num);	//Quan
	void insertStopWord(TrieNode*& stopword, string word);	//Quan
	void readFileStopWord(TrieNode*& stopword, ifstream& fin, string path);	//Quan
	bool isAccepted(char& key);			//Phat
	int convert(char key);				//Phat
	string filter(string sen);			//Phat
	void inputFile(TrieNode*& root, ifstream& file, string path);				//Khanh
	void insertSentence(TrieNode*& root, string sen, int& pos, bool isTitle);	//Khanh
	void insertWord(TrieNode*& root, string word, int& pos, bool isTitle);		//Khanh
	bool checkOperator(string sen);		//Phat
	TrieNode* searchWord(TrieNode* root, string word, bool isTitle);			//Quang
	bool searchTrie(TrieNode* root, TrieNode* stopwordRoot, vector<int>& pos, int& rankScore, string query);	//Quang
	void merge(vector<int>& vec1, vector<int> vec2);	//Quang
	void releaseTrie(TrieNode*& root);					//Quang
	void match(vector<int>& vec1, vector<int>& vec2, int asterisk);	//Quang
	pair<int,int> findAsterisk(string query);
	void findRange(string query, double& low, double& high);	//Phat
	void searchNumber_DFS(TrieNode* root, double low, double high, double num, int power, vector<int>& pos);
	void Synonyms(string word, vector<string>& syno);
	void historySuggestion(string query, vector<string>& his);
	void historySuggestionInterface(string& query);
	void viewHistory(string path);
	void updateHistory(string query, string path);
	int countWord(string sen); 
	void display(File file, string path);

	void Interface();
	void titleInterface(int& choice);
	void readInQuery(string& query);
	void searchInterface(int& choice);
	void searchProcess(string query, TrieNode* root[100], TrieNode* stopword);
	string getFileName(int i);
};

#endif // !_SEARCH_ENGINE_H_


